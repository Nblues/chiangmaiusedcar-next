module.exports = {
  images: {
    domains: ['cdn.shopify.com', 'kn-goodcar.com'],
  },
  reactStrictMode: true,
};
